# Como aplicar isso no seu repositório

Estes 9 arquivos substituem os arquivos de mesmo nome dentro de `api-reference/` no
seu repositório GitHub (`V1-main`). São drop-in replacements — mesmo nome, mesmo lugar,
só o conteúdo mudou.

| Arquivo | O que mudou |
|---|---|
| `introducao.mdx` | Listava recursos genéricos de SaaS; agora reflete os grupos reais do Swagger e avisa quais grupos ainda não têm página. |
| `autenticacao.mdx` | Removida a menção a expiração de 24h e painel de "Chaves de API" (não existem no Swagger). Agora explica que `usuario`/`senha` são credenciais de 32/64 caracteres geradas na tela 669 — não login comum. |
| `cte.mdx` | Trocado `POST /v1/cte` fictício pelos 4 endpoints reais em `/dfe/cte*` (consulta e cancelamento). Emissão de CT-e ficou em `entregas.mdx`, onde ela realmente está no Swagger. |
| `entregas.mdx` | Trocado o CRUD fictício de `/v1/delivery` pelos 5 endpoints reais de **minuta** (`/operacional/*/minuta`, `/operacional/emissao/cte`). |
| `mdfe.mdx` | Trocado `POST /v1/mdfe` fictício pelos 7 endpoints reais de manifesto. |
| `coletas.mdx` | Já existia como conceito; conteúdo agora vem dos 5 endpoints reais de `/operacional/*/coleta*`. |
| `rastreamento.mdx` | Trocado `/v1/tracking/{id}` (UUID) fictício pelos 10 endpoints reais de `/tracking/ocorrencias*` (busca por NF-e, CT-e, minuta, coleta, CNPJ, pedido, autorização de frete). |
| `financeiro.mdx` | Trocado `GET /v1/financeiro` fictício pelos 4 endpoints reais de fatura e liquidação. |
| `erros.mdx` | Já estava genérico; agora mostra os 6 formatos de erro reais (400/401/403/404/405/500) com os exemplos exatos do Swagger. |

## Como cada endpoint foi escrito

Os campos, tipos, obrigatoriedade e valores de `enum` vieram diretamente do
`openapi.json` que convertemos do seu Swagger — não foram reescritos à mão, então
refletem exatamente o que está (ou deveria estar) implementado no backend.

Os JSONs de resposta de exemplo são os mesmos exemplos que já existiam no Swagger
original, só reformatados para leitura (o Swagger tinha alguns exemplos como uma
única linha de texto, às vezes com comentários `//` inline).

## O que NÃO foi resolvido aqui

Os 6 problemas do relatório anterior (`$ref` quebrado, path parameter não documentado
em `/cadastro/trechos/{idTabela}`, enum incompleto em `tpMan`, tipo incoerente em
`/operacional/custos`, endpoint sem `security` em `/prazos/entrega`, descrição
copiada em `/dfe/cancela/cte`) continuam pendentes de confirmação com quem conhece o
backend. Nenhum deles afeta as 9 páginas acima, exceto o `tpMan` (aparece em
`mdfe.mdx` com o aviso "Único valor documentado no Swagger original: `1`" — o ideal é
o backend confirmar se são realmente 1/2/3/4 e atualizarmos).
